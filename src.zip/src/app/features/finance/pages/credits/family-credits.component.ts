import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GuardianChoice } from '../../models/finance-reference.model';
import { FamilyCredit } from '../../models/finance.model';
import { FamilyCreditService } from '../../services/family-credit.service';
import { FinanceReferenceService } from '../../services/finance-reference.service';
@Component({
  selector: 'app-family-credits',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './family-credits.component.html',
  styleUrl: './family-credits.component.scss',
})
export class FamilyCreditsComponent {
  private s = inject(FamilyCreditService);
  private refs = inject(FinanceReferenceService);
  guardians = signal<GuardianChoice[]>([]);
  selected = signal<GuardianChoice | null>(null);
  items = signal<FamilyCredit[]>([]);
  page = signal(0);
  size = signal(20);
  total = signal(0);
  pages = signal(0);
  error = signal('');
  search = '';
  searchGuardians() {
    this.refs.guardians(this.search, 0, 10).subscribe({
      next: (r) => this.guardians.set(r.content),
      error: (e) => this.error.set(this.msg(e)),
    });
  }
  choose(g: GuardianChoice) {
    this.selected.set(g);
    this.guardians.set([]);
    this.page.set(0);
    this.load();
  }
  load() {
    if (!this.selected()) return;
    this.s.search(this.selected()!.id, this.page(), this.size()).subscribe({
      next: (r) => {
        this.items.set(r.content);
        this.total.set(r.totalElements);
        this.pages.set(r.totalPages);
      },
      error: (e) => this.error.set(this.msg(e)),
    });
  }
  prev() {
    if (this.page() > 0) {
      this.page.update((v) => v - 1);
      this.load();
    }
  }
  next() {
    if (this.page() + 1 < this.pages()) {
      this.page.update((v) => v + 1);
      this.load();
    }
  }
  msg(e: any) {
    return e?.error?.message ?? 'Une erreur est survenue.';
  }
}
