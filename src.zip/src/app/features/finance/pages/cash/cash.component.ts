import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AuthService } from '../../../../core/config/auth/services/auth.service';

import { CampusRef } from '../../models/finance-reference.model';

import {
  CashMovement,
  CashMovementRequest,
  CashRegister,
  CashRegisterRequest,
  CashRegisterSession,
} from '../../models/finance.model';

import { CashMovementService } from '../../services/cash-movement.service';
import { CashRegisterService } from '../../services/cash-register.service';
import { FinanceReferenceService } from '../../services/finance-reference.service';
import { FinanceSessionStateService } from '../../services/finance-session-state.service';

@Component({
  selector: 'app-cash',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './cash.component.html',
  styleUrl: './cash.component.scss',
})
export class CashComponent {
  private s = inject(CashRegisterService);
  private moves = inject(CashMovementService);
  private refs = inject(FinanceReferenceService);
  private state = inject(FinanceSessionStateService);

  auth = inject(AuthService);

  registers = signal<CashRegister[]>([]);
  campuses = signal<CampusRef[]>([]);

  /**
   * Session actuellement mémorisée par FinanceSessionStateService.
   */
  session = this.state.current;

  movements = signal<CashMovement[]>([]);

  error = signal('');

  registerModal = signal(false);
  movementModal = signal(false);
  closeModal = signal(false);

  editing = signal<CashRegister | null>(null);

  registerForm: CashRegisterRequest = {
    code: '',
    name: '',
    campusId: null,
    active: true,
  };

  openRegisterId: number | null = null;

  openingBalance = 0;

  actualClosingBalance = 0;

  movementForm: CashMovementRequest = {
    cashRegisterSessionId: 0,
    movementType: 'ADJUSTMENT',
    direction: 'IN',
    amount: 0,
    reference: null,
    description: null,
  };

  constructor() {
    /*
     * Charge la liste des caisses.
     */
    this.load();

    /*
     * IMPORTANT :
     * si une session avait déjà été ouverte et mémorisée,
     * il faut immédiatement charger ses mouvements.
     *
     * Avant cette correction, la session apparaissait bien
     * mais movements() restait [].
     */
    this.loadMovements();

    /*
     * Charge les campus.
     */
    this.refs.campuses().subscribe({
      next: (x) => {
        this.campuses.set(x);
      },

      error: (e) => {
        this.error.set(this.msg(e));
      },
    });
  }

  /*
   * =========================================================
   * CAISSES
   * =========================================================
   */

  load(): void {
    this.s.all().subscribe({
      next: (x) => {
        this.registers.set(x);

        /*
         * Si aucune caisse n'est encore sélectionnée,
         * sélectionne la première caisse active.
         */
        if (!this.openRegisterId) {
          this.openRegisterId = x.find((c) => c.active)?.id ?? null;
        }
      },

      error: (e) => {
        this.error.set(this.msg(e));
      },
    });
  }

  openCreate(): void {
    this.editing.set(null);

    this.registerForm = {
      code: '',
      name: '',
      campusId: null,
      active: true,
    };

    this.registerModal.set(true);
  }

  openEdit(x: CashRegister): void {
    this.editing.set(x);

    this.registerForm = {
      code: x.code,
      name: x.name,
      campusId: x.campusId,
      active: x.active,
    };

    this.registerModal.set(true);
  }

  saveRegister(): void {
    this.error.set('');

    const op = this.editing()
      ? this.s.update(this.editing()!.id, this.registerForm)
      : this.s.create(this.registerForm);

    op.subscribe({
      next: () => {
        this.registerModal.set(false);

        this.load();
      },

      error: (e) => {
        this.error.set(this.msg(e));
      },
    });
  }

  /*
   * =========================================================
   * SESSION DE CAISSE
   * =========================================================
   */

  openSession(): void {
    if (!this.openRegisterId) {
      this.error.set('Sélectionne une caisse.');
      return;
    }

    this.error.set('');

    this.s
      .openSession({
        cashRegisterId: this.openRegisterId,
        openingBalance: Number(this.openingBalance),
      })
      .subscribe({
        next: (x) => {
          /*
           * Mémorise la nouvelle session.
           */
          this.state.set(x);

          /*
           * Réinitialise la liste avant le chargement.
           */
          this.movements.set([]);

          /*
           * Charge immédiatement les éventuels mouvements.
           */
          this.loadMovements();
        },

        error: (e) => {
          this.error.set(this.msg(e));
        },
      });
  }

  /*
   * =========================================================
   * MOUVEMENTS
   * =========================================================
   */

  loadMovements(): void {
    const currentSession = this.session();

    if (!currentSession) {
      this.movements.set([]);

      return;
    }

    this.error.set('');

    this.moves.search(currentSession.id, 0, 100).subscribe({
      next: (response) => {
        /*
         * L'API retourne PageResponse<CashMovement>.
         * Les lignes sont donc dans response.content.
         */
        this.movements.set(response.content ?? []);
      },

      error: (e) => {
        console.error('Erreur chargement mouvements caisse', e);

        this.movements.set([]);

        this.error.set(this.msg(e));
      },
    });
  }

  openMovement(): void {
    const currentSession = this.session();

    if (!currentSession) {
      return;
    }

    this.movementForm = {
      cashRegisterSessionId: currentSession.id,
      movementType: 'ADJUSTMENT',
      direction: 'IN',
      amount: 0,
      reference: null,
      description: null,
    };

    this.movementModal.set(true);
  }

  saveMovement(): void {
    this.error.set('');

    this.moves.create(this.movementForm).subscribe({
      next: () => {
        this.movementModal.set(false);

        /*
         * Recharge immédiatement la table.
         */
        this.loadMovements();
      },

      error: (e) => {
        this.error.set(this.msg(e));
      },
    });
  }

  /*
   * =========================================================
   * CLÔTURE
   * =========================================================
   */

  close(): void {
    const currentSession = this.session();

    if (!currentSession) {
      return;
    }

    this.error.set('');

    this.s
      .closeSession(currentSession.id, {
        actualClosingBalance: Number(this.actualClosingBalance),
      })
      .subscribe({
        next: (closedSession) => {
          this.closeModal.set(false);

          /*
           * On conserve temporairement la session clôturée
           * afin que l'écran puisse afficher :
           *
           * - attendu
           * - réel
           * - écart
           */
          this.state.set(closedSession);

          /*
           * Les mouvements restent visibles.
           */
          this.loadMovements();
        },

        error: (e) => {
          this.error.set(this.msg(e));
        },
      });
  }

  /*
   * =========================================================
   * HELPERS
   * =========================================================
   */

  campus(id: number | null): string {
    return id
      ? (this.campuses().find((x) => x.id === id)?.name ?? 'Campus')
      : '—';
  }

  msg(e: any): string {
    return e?.error?.message ?? 'Une erreur est survenue.';
  }
}
