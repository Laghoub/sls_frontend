import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../../../core/config/auth/services/auth.service';
import {
  PaymentDetail,
  PaymentMethod,
  Refund,
} from '../../models/finance.model';
import { PaymentMethodService } from '../../services/payment-method.service';
import { PaymentService } from '../../services/payment.service';
import { RefundService } from '../../services/refund.service';
@Component({
  selector: 'app-payment-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './payment-detail.component.html',
  styleUrl: './payment-detail.component.scss',
})
export class PaymentDetailComponent {
  private route = inject(ActivatedRoute);
  private s = inject(PaymentService);
  private refunds = inject(RefundService);
  private methodsService = inject(PaymentMethodService);
  auth = inject(AuthService);
  detail = signal<PaymentDetail | null>(null);
  refundItems = signal<Refund[]>([]);
  methods = signal<PaymentMethod[]>([]);
  error = signal('');
  cancelModal = signal(false);
  refundModal = signal(false);
  cancelReason = '';
  refundAmount = 0;
  refundReason = '';
  refundMethodId: number | null = null;
  refundCashSessionId: number | null = null;
  id = Number(this.route.snapshot.paramMap.get('id'));
  constructor() {
    this.methodsService.all().subscribe((x) => {
      this.methods.set(x);
      this.refundMethodId = x.find((m) => m.active)?.id ?? null;
    });
    this.load();
  }
  load() {
    this.s.get(this.id).subscribe({
      next: (d) => {
        this.detail.set(d);
        this.refunds
          .search(this.id, 0, 100)
          .subscribe((r) => this.refundItems.set(r.content));
      },
      error: (e) => this.error.set(this.msg(e)),
    });
  }
  allocatedTotal() {
    return (
      this.detail()?.allocations.reduce(
        (sum, a) => sum + Number(a.amount),
        0,
      ) ?? 0
    );
  }
  method(id: number) {
    return this.methods().find((m) => m.id === id)?.name ?? `Mode ${id}`;
  }
  cancel() {
    if (!this.cancelReason.trim()) return;
    this.s.cancel(this.id, this.cancelReason.trim()).subscribe({
      next: () => {
        this.cancelModal.set(false);
        this.load();
      },
      error: (e) => this.error.set(this.msg(e)),
    });
  }
  openRefund() {
    const p = this.detail()?.payment;
    this.refundAmount = p?.totalAmount ?? 0;
    this.refundReason = '';
    this.refundModal.set(true);
  }
  createRefund() {
    if (
      !this.refundMethodId ||
      this.refundAmount <= 0 ||
      !this.refundReason.trim()
    )
      return;
    this.refunds
      .create({
        paymentId: this.id,
        amount: this.refundAmount,
        paymentMethodId: this.refundMethodId,
        reason: this.refundReason.trim(),
        cashRegisterSessionId: this.refundCashSessionId,
      })
      .subscribe({
        next: () => {
          this.refundModal.set(false);
          this.load();
        },
        error: (e) => this.error.set(this.msg(e)),
      });
  }
  msg(e: any) {
    return e?.error?.message ?? 'Une erreur est survenue.';
  }
}
