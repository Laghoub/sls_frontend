import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
@Component({
  selector: 'app-finance-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './finance-home.component.html',
  styleUrl: './finance-home.component.scss',
})
export class FinanceHomeComponent {}
