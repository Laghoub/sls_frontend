import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { API_CONFIG } from '../../../core/api.config';
import {
  CashRegister,
  CashRegisterRequest,
  CashRegisterSession,
  CashSessionCloseRequest,
  CashSessionOpenRequest,
} from '../models/finance.model';
@Injectable({ providedIn: 'root' })
export class CashRegisterService {
  private http = inject(HttpClient);
  private url = `${API_CONFIG.baseUrl}/finance/cash-registers`;
  all() {
    return this.http.get<CashRegister[]>(this.url);
  }
  create(r: CashRegisterRequest) {
    return this.http.post<CashRegister>(this.url, r);
  }
  update(id: number, r: CashRegisterRequest) {
    return this.http.put<CashRegister>(`${this.url}/${id}`, r);
  }
  openSession(r: CashSessionOpenRequest) {
    return this.http.post<CashRegisterSession>(`${this.url}/sessions/open`, r);
  }
  closeSession(id: number, r: CashSessionCloseRequest) {
    return this.http.post<CashRegisterSession>(
      `${this.url}/sessions/${id}/close`,
      r,
    );
  }
}
